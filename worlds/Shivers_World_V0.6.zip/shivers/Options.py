import typing
from Options import Option, DeathLink, Range, Toggle


Shivers_options: typing.Dict[str,type(Option)] = {

}