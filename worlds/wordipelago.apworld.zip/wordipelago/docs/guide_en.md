# Wordipelago Start Guide

After rolling your seed, go to the [Wordipelago Game](https://apworlds.com/wordipelago) site, select Archipelago and enter the server details, your 
slot name, and a room password if one is required. Then click "Connect".

Once you're connected, you can start your guessing.

Wordipelago runs in most major browsers that support HTML5, so you can load Wordipelago on your phone and be productive while you wait!

